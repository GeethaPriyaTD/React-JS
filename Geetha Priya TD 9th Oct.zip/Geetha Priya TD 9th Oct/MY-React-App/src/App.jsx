import React from 'react'
import FirstComponent from './FirstComponent'
import Fruits from './classOne'
import Parent from './PropsChildren'

function App() {
  return (
    <div>
      <FirstComponent name="Geetha Priya"/>
      <FirstComponent name="Geetha Priya"/>
      <FirstComponent name="Geetha Priya"/>
      <Fruits />
      <Parent />


    </div>
  )
}


export default App