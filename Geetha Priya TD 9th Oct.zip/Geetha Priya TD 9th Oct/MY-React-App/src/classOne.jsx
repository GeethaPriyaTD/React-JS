import React from "react";

class Fruits extends React.Component{
    render() {
        return <h1>This is Class Component</h1>
    }
}

export default Fruits;