import React from 'react'

function FirstComponent(priya) {
  return (
    <div>
        <h1>FirstComponent {priya.name}</h1>
        <h2><SecondComponent phn="8618786215" /></h2>
    </div>
    
  )
}

function SecondComponent(priya) {
  return (
    <div>SecondComponent {priya.phn}</div>
  )
}

export default FirstComponent




