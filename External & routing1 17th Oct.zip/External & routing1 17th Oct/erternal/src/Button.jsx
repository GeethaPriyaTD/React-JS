import styles from "./Button.module.css";
function Button() {
    return<button ClassName={styles.btn}>Click Me</button>;
}

export default Button; 