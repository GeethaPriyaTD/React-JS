import "./ExternalCSS.css";
function External() {
    return <h1 className="title">React External CSS</h1>
}

export default External;