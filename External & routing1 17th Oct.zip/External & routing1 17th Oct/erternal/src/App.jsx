import React from 'react'
import External from './External'
import Button from './Button'
import ProductCard from './Styledcomponent'


function App() {
 

  return (
   <div>
    <External/>
    <Button/>
    <ProductCard/>
   </div>
  )
}

export default App
