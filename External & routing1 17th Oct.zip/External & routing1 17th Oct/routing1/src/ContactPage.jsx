import React from 'react'

function ContactPage() {
  return (
    <div>
        <h1>This is ContactPage</h1>
    </div>
  )
}

export default ContactPage