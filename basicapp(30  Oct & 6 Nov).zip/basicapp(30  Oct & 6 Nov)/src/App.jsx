//2.Modal1.jsx
import React from 'react'
import Modal1 from "./Modal1";
import {useState} from 'react';

function App() {
  const [open, setOpen]=useState(false);
  return (
    <>
      <button onClick={()=>setOpen(true)} style={{backgroundColor:"green"}}>Open Modal</button>
      {open && ( <Modal1>
        <div style={{backgroundColor:"orange"}}>
        <div>Hello This is A Notification</div>
   <div>
     <button onClick={()=>setOpen(false)} style={{backgroundColor:"blue"}}>Close</button>
    </div>
    </div>
      </Modal1>)}
      
   </>
    
  )
}

export default App
