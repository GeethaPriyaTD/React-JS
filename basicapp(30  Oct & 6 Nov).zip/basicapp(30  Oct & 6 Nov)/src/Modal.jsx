import React from 'react'
import ReactDOM from 'react-dom';

export default function Modal({children}) {
    const overlayStyle={
     position:"fixed",
     top:0,
     left:0,
     right:0,
     bottom:0,
     backgroungColor:"orange",
     zIndex:999,
    };
    const modalStyle={
     position:"fixed",
     top:0,
     left:0,  
    }
  return ReactDOM.createPortal(
   <>
    <div style={overlayStyle}></div>
    <div style={modalStyle}>{children}</div>
   </>,
   document.getElementById("modal-root")
);
  
}

// export default Model