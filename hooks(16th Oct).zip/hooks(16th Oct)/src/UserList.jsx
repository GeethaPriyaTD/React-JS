import React,{useEffect,useState} from 'react'

function UserList() {
    const[user,setUsers]=useState([]);
    const[loading,setloading]=useState(true);
    useEffect(()=>{
        async function fetchData() {
            const res = await
            fetch("https://jsonplaceholder.typicode.com/users");
            const data=await res.json();
            setUsers(data);
            setloading(false);
        }
        fetchData();
    },[]); //fetch once
  return (
    <div>
        <h2>User List</h2>
        {loading ? (
            <p>Loading...</p>
        ): (
            <ul>
                {user.map((user)=>(
                   <div>
                     <li key={user.id}>{user.name} </li>
                     <img src={user.image}/>
                   </div>
                ))}
            </ul>
        )}
    </div>
  );
}

export default UserList;