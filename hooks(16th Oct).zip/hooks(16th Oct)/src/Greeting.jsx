import React from 'react'
const style={
    backgroundColor:"Lightgreen",
    padding:"10x",
    borderRadius:"5px",
};

function Greeting() {
    return <h2 style={style}>Hello Inline styling! </h2>
}

export default Greeting;