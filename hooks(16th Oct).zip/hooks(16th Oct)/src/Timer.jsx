import React,{useEffect,useState} from 'react';

function Timer() {
    const[seconds,setseconds]=useState(0);
    useEffect(() => {
        const timer=setInterval(() => {
            setseconds((s) =>s+1);
        },1000);
        //cleaup function

  return () => {
    clearInterval(timer);
    console.log("Timer Cleared!");
  };
},[]); //run once
return <h2>Time:{seconds}s</h2>
   
}

export default Timer;
