import React from 'react'

function Temperature({value}) {
    return (
        <p style={{color:value > 30 ? "red":"orange"}}> Temperature:{value}°C</p>
    );
}

export default Temperature;