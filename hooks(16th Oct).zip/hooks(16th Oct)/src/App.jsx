import Counter from './Counter'
import Example from './Example'
import Timer from './Timer'
import UserList from './UserList'
import Temperature from './Temperature'
import Greeting from './Greeting'

function App() {
  
  return (
    
      <div>
        
        <Example/>
        <Counter/>
        <Timer/>
        <UserList/>
        <Greeting/>
        <Temperature/>
       </div>
  )
}

export default App
