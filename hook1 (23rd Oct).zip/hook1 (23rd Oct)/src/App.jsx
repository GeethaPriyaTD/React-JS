import React from 'react'
import Component1 from './ContextApi'
import Ref from './Ref'
import AccessingDom from './AccessingDom'
import Track from './Track'
import Battery1 from './Battery'

function App() {
  return (
    <div>
      <Component1/>
      <Ref/>
      <AccessingDom/>
      <Track/>
      <Battery1 />
    </div>
  )
}

export default App