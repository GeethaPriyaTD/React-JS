import { useBatteryStatus } from '@nikadev/use-battery-status';

function Battery1() {
  const { 
    isLoading,
    isSupported,
    level,
    charging,
    chargingTime,
    dischargingTime
  } = useBatteryStatus();

  if (!isSupported) {
    return <div>Battery API is not supported in your browser</div>;
  }

  if(isLoading) {
    return <div>Loading Battery data...</div>
  }

  return (
    <div>
      <p>Battery Level: {level * 100}%</p>
      <p>Charging: {charging ? 'Yes' : 'No'}</p>
      <p>Time until charged: {chargingTime} seconds</p>
      <p>Time until empty: {dischargingTime} seconds</p>
    </div>
  );
}

export default Battery1;