import React, { useReducer } from 'react';

function Counter1() {
function reducer(state,action) {
    switch (action.type) {
        case "INCREMENT":return {count:state.count + 1};
        case "DECREMENT":return { count:state.count -1};
        case "POSTINCREMENT":return { count:state.count + 2};
        case "RESET": return{cont:0};
        default:return state;
    }
}
const [state, dispatch]=useReducer(reducer,{count:0});
//initialize state using useReducer
return (
    <div style={{textAlig:"center", marginTop:"50px"}}>
        <h2>Count: {state.count}</h2>

        <button on onClick={() => dispatch( { type:"INCREMENT"})}>+ INCREMENT</button>
         <button on onClick={() => dispatch( { type:"DECREMENT"})}>- DECREMENT</button>
          <button on onClick={() => dispatch( { type:"POSTINCREMENT"})}> +2 POSTINCREMENT</button>
          <button on onClick={() => dispatch( { type:"RESET"})}> RESET</button>
    </div>
)
}

export default Counter1;