import React from 'react'
import Counter from './Counter'
import Counter1 from './Counter1'
import UseMemo from './UseMemo'
import Parent from './UseCallback'
import CounterApp from './CounterApp'

function App() {
  return (
    <div>
       {/* <Counter />
       <Counter1 />
       <UseMemo/>
       <Parent/> */}
       <CounterApp/>
       
    </div>
  )
}

export default App