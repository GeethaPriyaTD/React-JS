import React, {useState, useCallback } from 'react';

function Child({ onClick}) {
    console.log("Child component re-rendered");
    return <button onClick={onClick}>Click Me</button>;
}

function Parent() {
    const [count, setCount]= useState(0);

    //useCallback keeps the same function unless dependencies change
    const handleClick = useCallback(() => {
        console.log("Button clicked!");
    }, []); // No dependency -> same function always

    return (
        <div>
            <h3>Count: {count}</h3>
            <button onClick={() => setCount(count + 1)}>Increment Count</button>
            <Child onClick={handleClick}/>
        </div>
    );
}

export default Parent;