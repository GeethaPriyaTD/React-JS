import React, { useState } from 'react';
// Custom Hook to mange counter logic 
function UseCounter(initialValue =0) {
    const [count, setCount]= useState(initialValue);

    const increment = () => setCount(count + 1);
    const decrement = () => setCount(count - 1);
    const reset = () => setCount(initialValue);

    //Return anything you want to share
    return { count, increment, decrement, reset };
}

export default UseCounter;