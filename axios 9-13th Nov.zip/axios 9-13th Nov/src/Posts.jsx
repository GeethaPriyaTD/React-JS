import { useQuery } from '@tanstack/react-query';
import react from 'react'
function Posts(){
    const {data,isLoading,isfetching, isError}=useQuery({
        querykey:["images"],
        queryFn: async ()=>{
            console.log("Fetching Images from API")
            const res=await fetch("https://picsum.photos/v2/list?page=2&limit=10");
            if(!res.ok) throw new Error
            ("Network Response is Not Ok");
            return res.json();

        },
        staleTime:10000,
    });
    if(isLoading) return <p>Loading Images..</p>
    if(isError) return <p>Error Loading Images</p>
    
    return(
        <div>
            <h2>Picsum gallery</h2>
            {isfetching && <p>Refetching In Background......</p>}
<div> 
    <h2>Posts List</h2>
    {data.map((img)=>(
        <div key={img.id}>
            <img src={img.download_url} alt={img.author} />
            <p>{img.author}</p>
            </div>
 
    ))}

</div>
</div>
    )
}
export default Posts;