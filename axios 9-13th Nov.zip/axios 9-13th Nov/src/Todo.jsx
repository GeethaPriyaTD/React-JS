import axios from 'axios';
import React, { useState, useEffect } from 'react';
function Todo() {
    const [todos, setTodos] = useState([]);
    const [loading, setLoading]=useState(false);
    const [error, setError] = useState(null);
    const [limit, setLimit] = useState(10)

    useEffect(() =>{
        axios.get("https://jsonplaceholder.typicode.com/todos/")
        .then(res =>setTodos(res.data))
        .catch(err =>setError(err))
    },[]);

    const handleLoadMore = () =>
    {
        setLimit((preventLimit) => preventLimit + 5);
    }
    if (error) return <p>Error fetching todos:{error.message}</p>;
    if(loading) return <p>Loading....🔄️</p>

    return ( 
        <div>
            <h1>Todo List </h1>
            {todos.slice(0,limit).map((todos)=>(
                <div style={{...StyleSheet.todos,backgroundColor:todos.completed ? "green":"red",}}
                key={todos.id}>
                    <h1>{todos.title}</h1>
                    <p>Status: {todos.completed ? "Completed✅":"Pending....🔄️"}</p>
                </div>
            ))}
            {limit < todos.length && (
            <button style={{ backgroundColor: "blue" }} onClick={handleLoadMore}>
             Load More
            </button>
         
      )}
        </div>
    )
}

export default Todo;