import React, { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import Posts from "./Posts";

const client = new QueryClient();

function App() {
  const [showImages, setShowImages] = useState(true);

  return (
    <QueryClientProvider client={client}>
      <div>
        
        <button onClick={() => setShowImages((prev) => !prev)}>
          {showImages ? "Hide Images" : "Show Images"}
          {showImages && <Posts/>}
        </button>
      </div>
      <ReactQueryDevtools initialIsOpen={false}/>
    </QueryClientProvider>
  );
}

export default App;