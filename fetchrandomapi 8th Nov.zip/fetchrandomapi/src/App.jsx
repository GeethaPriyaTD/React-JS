import React, { useState } from "react";
import Modal from "./Modal";

function App() {
  const [open, setOpen] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);
  const [images, setImages] = useState([]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setOpen(false);
    setLoginSuccess(true);

    try {
      const res = await fetch("https://picsum.photos/v2/list?limit=9");
      const data = await res.json();
      const imageUrls = data.map((img) => img.download_url);
      setImages(imageUrls);
    } catch (error) {
      console.error("Error fetching random images:", error);
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: loginSuccess ? "orange" : "white",
        flexDirection: "column",
        padding: "20px",
      }}
    >
      {/* Centered Login Button */}
      {!loginSuccess && !open && (
        <button
          onClick={() => {
            setOpen(true);
            setLoginSuccess(false);
            setImages([]);
          }}
          style={{
            backgroundColor: "orange",
            color: "black",
            padding: "25px 60px",
            borderRadius: "12px",
            border: "none",
            cursor: "pointer",
            fontSize: "22px",
            fontWeight: "bold",
            boxShadow: "0 4px 8px rgba(0,0,0,0.3)",
          }}
        >
          Click to Login
        </button>
      )}

      {/* Login Modal */}
      {open && (
        <Modal>
          <div
            style={{
              backgroundColor: "lightgreen",
              padding: "80px",
              borderRadius: "10px",
              textAlign: "center",
              width: "400px",
              boxShadow: "0 4px 10px rgba(0,0,0,0.3)",
            }}
          >
            <h2 style={{ marginBottom: "20px" }}>Login</h2>
            <form onSubmit={handleLogin}>
              <div style={{ marginBottom: "20px" }}>
                <label htmlFor="name">Username / Email</label>
                <br />
                <input
                  type="text"
                  id="name"
                  name="name"
                  style={{
                    width: "100%",
                    padding: "10px",
                    marginTop: "8px",
                    borderRadius: "5px",
                    border: "1px solid #ccc",
                  }}
                  required
                />
              </div>
              <div>
                <label htmlFor="password">Password</label>
                <br />
                <input
                  type="password"
                  id="password"
                  name="password"
                  style={{
                    width: "100%",
                    padding: "10px",
                    marginTop: "8px",
                    borderRadius: "5px",
                    border: "1px solid #ccc",
                  }}
                  required
                />
              </div>
              <button
                type="submit"
                style={{
                  backgroundColor: "white",
                  color: "black",
                  padding: "12px 40px",
                  marginTop: "30px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                  fontWeight: "bold",
                }}
              >
                Submit
              </button>
            </form>
          </div>
        </Modal>
      )}

      {/* Full-Screen Gallery After Login */}
      {loginSuccess && (
        <div
          style={{
            width: "100%",
            height: "100vh",
            overflowY: "auto",
            padding: "30px",
            textAlign: "center",
          }}
        >
          <h2 style={{ marginBottom: "20px", color: "black" }}>
            Form Submitted Successfully ✅
          </h2>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: "20px",
              justifyItems: "center",
            }}
          >
            {images.map((url, index) => (
              <div
                key={index}
                style={{
                  width: "100%",
                  height: "250px",
                  overflow: "hidden",
                  borderRadius: "15px",
                  boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
                  transition: "transform 0.3s ease",
                }}
              >
                <img
                  src={url}
                  alt={`Random ${index}`}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    borderRadius: "15px",
                    transition: "transform 0.3s ease",
                  }}
                  onMouseOver={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
                  onMouseOut={(e) => (e.currentTarget.style.transform = "scale(1)")}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
