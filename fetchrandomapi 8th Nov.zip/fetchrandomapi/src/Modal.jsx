import { createPortal } from 'react-dom';

function Modal({ children }) {
  return createPortal(
    <div className="modal"
         style={{
           position: 'fixed',
           top: 0,
           left: 0,
           width: '100%',
           height: '100%',
           backgroundColor: 'rgba(0,0,0,0.4)',
           display: 'flex',
           alignItems: 'center',
           justifyContent: 'center',
           fontFamily:'Arial, sans-serif'
         }}>
         
      {children}
    </div>,
    document.getElementById('modal-root')
  );
}

export default Modal;
