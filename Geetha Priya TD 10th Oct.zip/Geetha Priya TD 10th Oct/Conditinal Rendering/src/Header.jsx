import React from 'react';

function Header({ cartCount }) {
  return (
    <header className="header">
      <h1>React Store</h1>
      <div className="cart-badge">🛒 Cart: {cartCount}</div>
    </header>
  );
}

export default Header;
