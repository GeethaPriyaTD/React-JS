import React, { useState } from 'react';
import Header from './Header';
import ProductList from './ProductList';
import './styles.css';

function App() {
  const [cartCount, setCartCount] = useState(0);

  const products = [
    { id: 1, name: 'Laptop', price: 75000, available: true },
    { id: 2, name: 'Headphones', price: 2500, available: false },
    { id: 3, name: 'Smartphone', price: 55000, available: true },
    { id: 4, name: 'Keyboard', price: 1500, available: false },
  ];

  const handleAddToCart = () => {
    setCartCount(prev => prev + 1);
  };

  return (
    <div className="store-container">
      <Header cartCount={cartCount} />
      <ProductList products={products} addToCart={handleAddToCart} />
    </div>
  );
}

export default App;
