import React from 'react';
import Card from './Card';

function ProductItem({ product, addToCart }) {
  const { name, price, available } = product;

  const cardStyle = {
    backgroundColor: available ? '#fff' : '#f8d7da',
  };

  return (
    <Card>
      <div className="product-card" style={cardStyle}>
        <h3>{name}</h3>
        <p>₹{price}</p>

        {price > 50000 && <p className="offer">🎉 Special Offer Available!</p>}

        {available ? (
          <button onClick={addToCart}>Add to Cart</button>
        ) : (
          <span className="out-of-stock">Out of Stock</span>
        )}
      </div>
    </Card>
  );
}

export default ProductItem;
