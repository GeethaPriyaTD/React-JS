import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForm from './ControledForm'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './FormValidation'

function App() {
  return (
    <div>
      <HtmlForms />
      <ControlledForm />
      <TwoWayBinding />
      <SimpleValidation />
    </div>
  )
}


export default App