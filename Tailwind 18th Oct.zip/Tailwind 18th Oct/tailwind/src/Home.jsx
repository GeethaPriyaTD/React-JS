// Home.js
export default function Home() {
  return <h2>Welcome to Home Page</h2>;
}